import os, urllib
import urllib.request
from zipfile import ZipFile

def getData(file, url, folder):
    if not os.path.isfile(FILE):
        print(f"Downloading {url} and saving as {file}")
        urllib.request.urlretrieve(url, file)
    if ".zip" in url:
        print("unzipping Data...")
        with ZipFile(file) as zipDaten:
            zipDaten.extractcall(folder)
    print("Done")