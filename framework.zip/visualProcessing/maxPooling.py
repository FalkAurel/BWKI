import numpy as np

#Quellen https://numpy.org/doc/stable/reference/generated/numpy.mgrid.html
#https://lanstonchu.wordpress.com/2018/09/01/convolutional-neural-network-cnn-backward-propagation-of-the-pooling-layers/

class MaxPooling():
    def __init__(self, *, maxPoolingSize=2):
        self.maxPoolingSize = maxPoolingSize
    
    def forward(self, image):
        self._input = image
        b,h, w  = image.shape
        output = np.zeros((b, h // self.maxPoolingSize, w // self.maxPoolingSize))
        self._maxOutputIndeces = np.copy(output)
        for batch in range(b):
            for y in range(0, h - h % self.maxPoolingSize, self.maxPoolingSize):
                for x in range(0, w - w % self.maxPoolingSize, self.maxPoolingSize):
                    Y, X = y // self.maxPoolingSize, x // self.maxPoolingSize
                    output[batch, Y, X] = np.max(image[batch, y:y+self.maxPoolingSize, x:x+self.maxPoolingSize])
                    self._maxOutputIndeces[batch, Y, X] = np.argmax(image[batch, y:y+self.maxPoolingSize, x:x+self.maxPoolingSize])
        return output
    
    def forwardOptim(self, image):
        self._input = image
        _, y, x = image.shape
        image = image[:y - y % self.maxPoolingSize, :x - x % self.maxPoolingSize]
        #self._maxOutputIndeces = image.reshape(-1, y // self.maxPoolingSize, self.maxPoolingSize, x // self.maxPoolingSize, self.maxPoolingSize).argmax()
        return image.reshape(-1, y // self.maxPoolingSize, self.maxPoolingSize, x // self.maxPoolingSize, self.maxPoolingSize).max(axis=(2, 4))
    
    def backward(self, gradient):
        dInput = np.zeros_like(self._input)
        b, h, w = self._input.shape
        B, Y, X = np.mgrid[0:b, 0:h - h % self.maxPoolingSize:self.maxPoolingSize, 0:w - w % self.maxPoolingSize:self.maxPoolingSize]
        Y //= self.maxPoolingSize
        X //= self.maxPoolingSize
        maxIndex = np.unravel_index(self._maxOutputIndeces[B,Y, X].astype(int), (b,self.maxPoolingSize, self.maxPoolingSize))
        dInput[maxIndex[0], Y * self.maxPoolingSize + maxIndex[1], X * self.maxPoolingSize + maxIndex[2]] = gradient[B, Y, X]
        return dInput
    def backward(self, gradient):
        dInput = np.zeros_like(self._input)
        

if __name__ == "__main__":
    test = np.array([[[1, 2, 3, 4],
                      [5, 6, 7, 8],
                      [1, 2, 3, 4],
                      [5, 6, 7, 8]],
                     [[1, 2, 3, 4],
                      [5, 6, 7, 8],
                      [1, 2, 3, 4],
                      [5, 6, 7, 8]]])
    gradient = np.array([[[1, 2],
                         [1, 2]],
                         [[1, 2],
                          [1, 2]]])
    m = MaxPooling()
    #output = m.forwardOptim(test)
    output1 = m.forward(test)
    dInput = m.backward(gradient)