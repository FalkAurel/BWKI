import numpy as np
import os
import sys
sys.path.insert(1, os.path.join(os.path.dirname(os.getcwd()), "nn"))
from ActivationFunction import ReLU

class Convolution(object):
    def __init__(self, kernelSize = 3, bias = 0):
        self.kernel = np.random.randn(kernelSize, kernelSize)
        self.kernelGröße = kernelSize
        self.padding = (kernelSize - 1) // 2
        self.relu = ReLU()
        self.bias = bias
        
    def kernelBerechnung(self, x):
        return np.sum(self.kernel * x)
    
    def forward(self, InputArray):
        self._input = InputArray
        InputArray = np.pad(InputArray, [(self.padding, self.padding), (self.padding, self.padding)], mode="constant")
        self.outputShape = (InputArray.shape[0] - self.kernelGröße + 1, InputArray.shape[1] - self.kernelGröße + 1)
        featureMap = np.zeros((self.outputShape))
        self.bias = np.random.randn(*self.outputShape)
        for y in range(self.outputShape[0]):
            for x in range(self.outputShape[1]):
                featureMap[y, x] = self.kernelBerechnung(InputArray[y:y + self.kernelGröße, x:x +self.kernelGröße])
        return self.relu.forward(featureMap + self.bias)
    
    def maxPooling(self, InputArray, size = 2):
        x = InputArray.shape[0] // size #setz Indecies für einen Array, der garantiert Array.shape[0] / size == 0 erfüllt
        y = InputArray.shape[1] // size
        return InputArray[:x*size, :y*size].reshape(x, size, y, size).max(axis = (1, 3))#mit den richtigen Indecies wird ein Teilstück aus dem Input "rausgeschnitten", in einen 3d Array umgewandelt, der die richtige size-Größe besitzenden 2d Array besitz. max holt uns den max val von den 2d Array
    
    def meanPooling(self, InputArray, size = 2):
        x = InputArray.shape[0] // size
        y = InputArray.shape[1] // size
        return InputArray[:x*size, :y*size].reshape(x, size, y, size).mean(axis = (1, 3))

class Flatten(object):
    def forward(self, InputArray):
        self.shape = InputArray.shape
        return np.ravel(InputArray)
    
    def backward(self, gradient):
        return gradient.reshape(self.shape)

test = np.array([[0, 55, 0, 0],
                 [20, 0, 41, 33],
                 [0, 90, 0, 0],
                 [0, 57, 0, 95]])