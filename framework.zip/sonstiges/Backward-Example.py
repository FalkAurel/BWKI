#params
x = [1, -2, 3]
w = [-3, -1, 2]
b = 1

#Multiplikation des Inputs mit den Weights
xw0 = x[0] * w[0]
xw1 = x[1] * w[1]
xw2 = x[2] * w[2]
print(xw0, xw1, xw2)

#Summierung der gewichteten Inputs und dem bias
z = xw0 + xw1 + xw2 + b
print(z)

#ActivationFunktion
reluOutput = max(z, 0)
print(reluOutput)
################################################Backpropagation#################################################
gradient = 1
dreluDZ = 1 if z > 0 else 0
db = dreluDZ
dsumDxw0 = 1#eigentlich unnötig, nur der Vollständigkeit halber
dsumDxw1 = 1
dsumDxw2 = 1
dx0 = dsumDxw0 * w[0]
dw0 = dsumDxw0 * x[0]
dx1 = dsumDxw1 * w[1]
dw1 = dsumDxw1 * x[1]
dx2 = dsumDxw2 * w[2]
dw2 = dsumDxw2 * x[2]

print(dx1, dw1)