import numpy as np
import time 
softmaxOutput = np.array([[0.7, 0.1, 0.2],
                          [0.8, 0.05, 0.15]])
gradient = np.array([[0.4, 5, 0.1],
                     [0.4, 0.6, 7]])
#erwarteterOutput = [[-0.28,  0.42, -0.14],[-0.8 , -0.04,  0.84]]
"""
softmax_output = np.array(softmaxOutput).reshape(-1, 1)

start = time.perf_counter()
output = np.eye(softmax_output.shape[0]) * softmax_output - np.dot(softmax_output, softmax_output.T)#
a = time.perf_counter() - start
start = time.perf_counter()
output = np.diagflat(softmax_output) - np.dot(softmax_output, softmax_output.T)#.T um ein row vector zu machen
b = time.perf_counter() - start
print(f"{(a - b) / b * 100}%")
"""

def backward(gradient):
    dInput = np.empty_like(gradient)
    for index, (einzelnOutput, einzelnGradient) in enumerate(zip(softmaxOutput, gradient)):
        einzelnOutput = einzelnOutput.reshape(-1, 1)
        jacobianMatrix = np.diagflat(einzelnOutput) - np.dot(einzelnOutput, einzelnOutput.T)
        print(np.dot(jacobianMatrix, einzelnGradient))
        dInput[index] = np.dot(jacobianMatrix, einzelnGradient)
    return dInput

start = time.perf_counter()
c = backward(gradient)
print(time.perf_counter() - start)
