import numpy as np
import random 

def dropOutLayer(weight, dropoutChance):
    index = [random.randint(0, 100)/ 100 for _ in range(len(weight))]
    for i, wert in enumerate(index):
        if wert < dropoutChance:
            weight[i] = 0
    return weight

dropout_rate = 0.3
example_output = np.array([0.27, -1.03, 0.67, 0.99, 0.05, -0.37, -2.01, 1.13, -0.07, 0.73]) 

#example_output *= np.random.binomial(1, 1-dropout_rate, example_output.shape)
print(f"initial sum: {np.sum(example_output)}")
sums = []
for i in range(10000):
    sums.append((example_output * np.random.binomial(1, 1-dropout_rate, example_output.shape) / (1-dropout_rate)).sum())
print(f"mean sum: {sum(sums) / len(sums)}") #division bei der Teilmenge handelt den Output für den Verlust von teilmengeNeuronen

