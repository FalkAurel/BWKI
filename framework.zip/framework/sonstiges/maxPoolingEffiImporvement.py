import numpy as np

windowSize = 2
test = np.array([[[1, 2],
                  [3, 4]],
                 [[1, 2],
                  [99, 4]]])

maxIndex = test.argmax(axis = -1)

newWindows = test[:test.shape[1] - test.shape[1]  % windowSize, :test.shape[-1] - test.shape[-1] % windowSize]
maxIndex1 = newWindows.reshape(-1, newWindows.shape[1] // windowSize, windowSize, newWindows.shape[-1] // windowSize, windowSize)
maxIndexN = maxIndex1.argmax(axis = -1)

a = test.reshape(-1)
a = a[:len(a) // test.shape[0]]

####################################################################################################################

shape = (2, 4, 4)
indexForOnes = np.array([[[3, 3],
                          [3, 3]],
                         [[3, 3],
                         [3, 3]]])

test = np.array([[[1, 2, 3, 4],
                      [5, 6, 7, 8],
                      
                      [1, 2, 3, 4],
                      [5, 6, 7, 8]],
                     
                     [[1, 2, 3, 4],
                      [5, 6, 7, 8],
                      [1, 2, 3, 4],
                      [5, 6, 7, 8]]])

out = np.zeros(shape)
binaryMask = np.transpose(np.where(test.reshape(-1, test.shape[1] // 2, 2, test.shape[2] // 2, 2).max(axis = (-3, -1))))
#out[np.where(indexForOnes == 3), 1, 0]
out[binaryMask] = 1