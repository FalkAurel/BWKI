import numpy as np
from time import perf_counter
from random import randint
import matplotlib.pyplot as plt

def timer(func):
    def wrapper(arg):
        start = perf_counter()
        func(arg)
        end = perf_counter()
        return end - start
    return wrapper

weight = [0.2, 0.8, -0.5] 
def L1Backward(weight):
    dL1 = []
    for i in weight:
        if i >= 0:
            dL1.append(1)
        else:
            dL1.append(-1)
    return dL1

w = [[randint(-100, 100) / 100 for _ in range(4)] for _ in range(3)]
print(w)

@timer
def L1BackwardLayer(weight):
    dL1 = []
    for neuron in weight:
        zwischenSpeicher = []
        for weight in neuron:
            if weight >= 0:
                zwischenSpeicher.append(1)
            else:
                zwischenSpeicher.append(-1)
        dL1.append(zwischenSpeicher)
    return dL1

weights = np.random.randn(3, 4)

"""
@timer
def L1backwardLayerNumpy(weight):
    weight[weight >= 0] = 1
    weight[weight < 0] = -1
    return weight
"""
@timer
def L1backwardLayerNumpy1(weight):
    return np.where(weight >= 0, 1, -1)
"""
@timer
def L1backwardLayerNumpy2(weight):
    dL1 = np.ones_like(weight)
    dL1[weight < 0] = -1
    return dL1
A, B, C = [], [], []
for _ in range(1000):
    a = L1backwardLayerNumpy(weights)
    b = L1backwardLayerNumpy1(weights)
    c = L1backwardLayerNumpy2(weights)
    A.append(a)
    B.append(b)
    C.append(c)
x = [i for i in range(1000)]
plt.plot(x, A, label = "A")
plt.plot(x, B, label = "B")
plt.plot(x, C, label = "C")
plt.legend()
plt.show()
print((a - b) / b * 100)
print((b - c) / c * 100)
print((a - c) / c * 100)
"""
