import numpy as np

def createData(sample = 1000):
    X = np.arange(sample) / sample
    y = np.sin(2 * np.pi * X)
    return X, y