import numpy as np

def save(filename, content):
    with open(filename, "wb") as f:
        np.save(f, content)

def load(filename):
    with open(filename, "rb") as f:
        return np.load(f)