import numpy as np

def strToNumeric(labels):
    """
    Returns strings as numerical Values. It returns the output array with the numerical values and a set which contains
    all the unique labels the postion of each label in the set corresponds to the numerical value assgined.
    """
    output = []
    uniqueLabel = {label for label in labels}
    def hashSetIndex(target, hashset):
        index = 0
        for element in hashset:
            if element == target:
                return index
            index += 1
    for label in labels:
        output.append(hashSetIndex(label, uniqueLabel))
    return np.array(output), uniqueLabel