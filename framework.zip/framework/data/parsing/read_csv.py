import numpy as np

def read_csv(filename, split):
    data = np.genfromtxt(filename, delimiter=split, dtype=object)
    return data