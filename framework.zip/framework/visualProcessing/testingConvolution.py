import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

weight = np.array([[[1, 2],
                   [-1, 0]]])

inputs = np.array([[[1, 6, 2],
                   [5, 3, 1],
                   [7, 0, 4]]])

gradient = np.array([[[7, 5],
                     [11, 3]]])

def crossCorrelation(a, b):
    subArrays = sliding_window_view(a, window_shape=b.shape)
    return np.tensordot(subArrays, b, axes=([2,3], [0,1]))

dweight = crossCorrelation(inputs, gradient)

print(dweight)
test = np.array([[[101.,  88.],
                  [127.,  38.]],
                 [[101.,  88.],
                  [127.,  38.]]])
print(np.allclose(test, dweight))

#print(np.allclose(test, dweight))