import numpy as np


def extractCoordinates(image):
    """
    extracts the coordinates for every pixel. Returns y-cords, x-cords in a 2d array.
    """
    height, width = image.shape[:2]
    return np.meshgrid(np.arange(width), np.arange(height))

def extractRGB(image, cords):
    """
    Takes an RGB-Image and a 2d array of cords. Extracts for every row in cords the corresponding RGB-Value-pair.
    Returns a 2d array of RGB-Values.
    """
    y, x = cords[:, 0], cords[:, 1]
    return image[y, x]

def fourierFeatureMapping(inputs, order):
    n = np.arange(1, order + 1)
    m = np.arange(1, order + 1)
    nMesh, mMesh = np.meshgrid(n, m)
    x0Cos = np.cos(nMesh[np.newaxis, :, :] * inputs[:, 0, np.newaxis, np.newaxis])
    x0Sin = np.sin(nMesh[np.newaxis, :, :] * inputs[:, 0, np.newaxis, np.newaxis])
    x1Cos = np.cos(mMesh[np.newaxis, :, :] * inputs[:, 1, np.newaxis, np.newaxis])
    x1Sin = np.sin(mMesh[np.newaxis, :, :] * inputs[:, 1, np.newaxis, np.newaxis])
    features = np.stack([x0Cos * x1Cos, x0Cos * x1Sin, x0Sin * x1Cos, x0Sin * x1Sin], axis=3).reshape(len(inputs), -1, 4)
    return features
#batch = fourierFeatureEncoding(np.hstack((x.reshape(-1, 1), y.reshape(-1, 1))))