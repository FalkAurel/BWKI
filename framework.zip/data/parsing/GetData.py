import cv2
import os
import numpy as np
    
def extract(ordner, subordner):
    ordner = os.path.join(ordner, subordner)
    kategorien = os.listdir(ordner)
    x, y = [], []
    for kategorie in kategorien:
       label = int(kategorie)
       print(label)
       for bild in os.listdir(os.path.join(ordner, kategorie)):
           image = cv2.imread(os.path.join(ordner, kategorie, bild), cv2.IMREAD_UNCHANGED)
           x.append(image)
           y.append(label)
    return np.array(x), np.array(y).astype("uint8")