from .GetData import extract as getImageData
from .speichernLaden import load as load
from .speichernLaden import save as save