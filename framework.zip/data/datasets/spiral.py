import numpy as np
import matplotlib.pyplot as plt

ob = []

#Data = https://cs231n.github.io/neural-networks-case-study/
def createData(sample, classes):
    X = np.zeros((sample * classes, 2))
    y = np.zeros(sample * classes, dtype='uint8')
    for classN in range(classes):
        index = range(sample*classN, sample*(classN+1))
        r = np.linspace(0.0, 1, sample)
        t = np.linspace(classN * 4, (classN + 1) * 4, sample) + np.random.randn(sample)*0.2
        X[index] = np.column_stack((r*np.sin(t*2.5), r*np.cos(t*2.5)))
        y[index] = classN
    return X,y

if __name__ == "__main__":
    X, y = createData(100, 3)
    plt.scatter(X[:, 0], X[:, 1], c=y, s=40, cmap=plt.cm.Set1)
    plt.show()
    
