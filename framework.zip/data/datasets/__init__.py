from .spiral import createData as spiralData
from .sinus import createData as sinusData